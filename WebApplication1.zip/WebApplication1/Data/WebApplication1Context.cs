﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Models;

namespace WebApplication1.Models
{
    public class WebApplication1Context : DbContext
    {
        public WebApplication1Context (DbContextOptions<WebApplication1Context> options)
            : base(options)
        {
        }

        public DbSet<WebApplication1.Models.Book> Book { get; set; } = default!;

        public DbSet<WebApplication1.Models.Author>? Author { get; set; }

        public DbSet<WebApplication1.Models.Genre>? Genre { get; set; }

        public DbSet<WebApplication1.Models.Review>? Review { get; set; }

        public DbSet<WebApplication1.Models.UserBooks>? UserBooks { get; set; }

        public DbSet<BookGenre> BookGenre { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Book>()
                .HasOne<Author>(p => p.Author)
                .WithMany(p => p.Books)
                .HasForeignKey(p => p.AuthorId);

            builder.Entity<BookGenre>()
                .HasOne<Book>(p => p.Book)
                .WithMany(p => p.Genres)
                .HasForeignKey(p => p.GenreId);

            builder.Entity<BookGenre>()
                .HasOne<Genre>(p => p.Genre)
                .WithMany(p => p.Books)
                .HasForeignKey(p => p.BookId);

            builder.Entity<Review>()
                .HasOne<Book>(p => p.Book)
                .WithMany(p => p.Reviews)
                .HasForeignKey(p => p.BookId);

            builder.Entity<UserBooks>()
                .HasOne<Book>(p => p.Book)
                .WithMany(p => p.Users)
                .HasForeignKey(p =>p.BookId);
            
        }
    }
}
