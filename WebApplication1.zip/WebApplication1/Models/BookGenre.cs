﻿using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class BookGenre
    {

        public int Id { get; set; }


        [Display(Name = "Book")]
        public int BookId { get; set; }
        public Book? Book { get; set; }

        [Display(Name = "Genre")]
        public int GenreId { get; set; }
        public Genre? Genre { get; set; }

        public ICollection<Book> Books { get; set;}

        public ICollection<Genre> Genres { get;}
    }
}
