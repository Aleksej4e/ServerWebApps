﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



namespace WebApplication1.Models
{
    public class SeedData
    {
        public static void Initialise(IServiceProvider serviceProvider)
        {
            using (var context = new WebApplication1Context(serviceProvider.GetRequiredService<DbContextOptions<WebApplication1Context>>()))
            {
                if (context.Book.Any() || context.Author.Any() || context.Genre.Any())
                {
                    return;
                }
                context.Author.AddRange(
                    new Author { FirstName = "Jack", LastName = "London", Gender = "Male", Nationality = "American" }
                    );
                context.SaveChanges();

                context.Genre.AddRange(
                    new Genre { GenreName = "KunstlerRoman" }
                   );
                context.SaveChanges() ;

                context.Book.AddRange(
                    new Book {YearPublished = 1909, DownloadUrl = "no", FrontPage = "https://upload.wikimedia.org/wikipedia/en/9/9b/MartinEden.jpg",  Description = "Martin Eden is a 1909 novel by American author Jack London about a young proletarian autodidact struggling to become a writer.", Publisher = "Macmillan", Title = "Martin Eden" }
                    );
                context.SaveChanges();
                context.BookGenre.AddRange(
                    new BookGenre { BookId=1, GenreId=1}
                    );
                context.SaveChanges();
            }


        }



    }
}
