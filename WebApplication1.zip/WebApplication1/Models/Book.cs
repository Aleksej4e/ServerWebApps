﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class Book
    {

        public int Id { get; set; }


        [StringLength(50)]
        public string Title { get; set; }

        public int YearPublished { get; set; }

        public int NumPages { get; set; }


        [StringLength(1000)]
        public string Description { get; set; }


        [StringLength(50)]
        public string Publisher { get; set; }

        [StringLength(1000)]
        public string FrontPage { get; set; }

        [StringLength(1000)]
        public string DownloadUrl { get; set; }

        [Display(Name = "Author")]
        public int? AuthorId { get; set; }
        public Author? Author { get; set; }
        
        public ICollection<Review> Reviews { get; set; }    

        public ICollection<UserBooks> Users { get; set; }

        public ICollection<BookGenre> Genres { get; set; }
    }

}
