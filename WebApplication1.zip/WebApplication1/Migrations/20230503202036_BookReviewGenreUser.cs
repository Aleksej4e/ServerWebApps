﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplication1.Migrations
{
    public partial class BookReviewGenreUser : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BookGenreId",
                table: "Genre",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<int>(
                name: "AuthorId",
                table: "Book",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "BookGenreId",
                table: "Book",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ReviewId",
                table: "Book",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserBooks_BookId",
                table: "UserBooks",
                column: "BookId");

            migrationBuilder.CreateIndex(
                name: "IX_Review_BookId",
                table: "Review",
                column: "BookId");

            migrationBuilder.CreateIndex(
                name: "IX_Genre_BookGenreId",
                table: "Genre",
                column: "BookGenreId");

            migrationBuilder.CreateIndex(
                name: "IX_BookGenre_BookId",
                table: "BookGenre",
                column: "BookId");

            migrationBuilder.CreateIndex(
                name: "IX_BookGenre_GenreId",
                table: "BookGenre",
                column: "GenreId");

            migrationBuilder.CreateIndex(
                name: "IX_Book_AuthorId",
                table: "Book",
                column: "AuthorId");

            migrationBuilder.CreateIndex(
                name: "IX_Book_BookGenreId",
                table: "Book",
                column: "BookGenreId");

            migrationBuilder.CreateIndex(
                name: "IX_Book_ReviewId",
                table: "Book",
                column: "ReviewId");

            migrationBuilder.AddForeignKey(
                name: "FK_Book_Author_AuthorId",
                table: "Book",
                column: "AuthorId",
                principalTable: "Author",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Book_BookGenre_BookGenreId",
                table: "Book",
                column: "BookGenreId",
                principalTable: "BookGenre",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Book_Review_ReviewId",
                table: "Book",
                column: "ReviewId",
                principalTable: "Review",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_BookGenre_Book_GenreId",
                table: "BookGenre",
                column: "GenreId",
                principalTable: "Book",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_BookGenre_Genre_BookId",
                table: "BookGenre",
                column: "BookId",
                principalTable: "Genre",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Genre_BookGenre_BookGenreId",
                table: "Genre",
                column: "BookGenreId",
                principalTable: "BookGenre",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Review_Book_BookId",
                table: "Review",
                column: "BookId",
                principalTable: "Book",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserBooks_Book_BookId",
                table: "UserBooks",
                column: "BookId",
                principalTable: "Book",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Book_Author_AuthorId",
                table: "Book");

            migrationBuilder.DropForeignKey(
                name: "FK_Book_BookGenre_BookGenreId",
                table: "Book");

            migrationBuilder.DropForeignKey(
                name: "FK_Book_Review_ReviewId",
                table: "Book");

            migrationBuilder.DropForeignKey(
                name: "FK_BookGenre_Book_GenreId",
                table: "BookGenre");

            migrationBuilder.DropForeignKey(
                name: "FK_BookGenre_Genre_BookId",
                table: "BookGenre");

            migrationBuilder.DropForeignKey(
                name: "FK_Genre_BookGenre_BookGenreId",
                table: "Genre");

            migrationBuilder.DropForeignKey(
                name: "FK_Review_Book_BookId",
                table: "Review");

            migrationBuilder.DropForeignKey(
                name: "FK_UserBooks_Book_BookId",
                table: "UserBooks");

            migrationBuilder.DropIndex(
                name: "IX_UserBooks_BookId",
                table: "UserBooks");

            migrationBuilder.DropIndex(
                name: "IX_Review_BookId",
                table: "Review");

            migrationBuilder.DropIndex(
                name: "IX_Genre_BookGenreId",
                table: "Genre");

            migrationBuilder.DropIndex(
                name: "IX_BookGenre_BookId",
                table: "BookGenre");

            migrationBuilder.DropIndex(
                name: "IX_BookGenre_GenreId",
                table: "BookGenre");

            migrationBuilder.DropIndex(
                name: "IX_Book_AuthorId",
                table: "Book");

            migrationBuilder.DropIndex(
                name: "IX_Book_BookGenreId",
                table: "Book");

            migrationBuilder.DropIndex(
                name: "IX_Book_ReviewId",
                table: "Book");

            migrationBuilder.DropColumn(
                name: "BookGenreId",
                table: "Genre");

            migrationBuilder.DropColumn(
                name: "BookGenreId",
                table: "Book");

            migrationBuilder.DropColumn(
                name: "ReviewId",
                table: "Book");

            migrationBuilder.AlterColumn<int>(
                name: "AuthorId",
                table: "Book",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);
        }
    }
}
